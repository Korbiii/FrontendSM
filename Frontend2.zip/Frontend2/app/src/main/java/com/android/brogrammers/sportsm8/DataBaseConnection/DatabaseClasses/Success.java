package com.android.brogrammers.sportsm8.DataBaseConnection.DatabaseClasses;

/**
 * Created by Korbi on 14.06.2017.
 */

public class Success {
    public int success;
}
