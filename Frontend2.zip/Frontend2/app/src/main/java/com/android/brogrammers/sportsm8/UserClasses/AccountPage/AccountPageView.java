package com.android.brogrammers.sportsm8.UserClasses.AccountPage;

import com.android.brogrammers.sportsm8.DataBaseConnection.DatabaseClasses.UserInfo;

/**
 * Created by Korbi on 13.09.2017.
 */

public interface AccountPageView {
    void displayUserInfo(UserInfo userInfo);
}
