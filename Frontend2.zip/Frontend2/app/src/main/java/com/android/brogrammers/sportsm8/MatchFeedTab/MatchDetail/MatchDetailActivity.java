package com.android.brogrammers.sportsm8.MatchFeedTab.MatchDetail;

/**
 * Created by Korbi on 26.06.2017.
 */

public class MatchDetailActivity {
}
