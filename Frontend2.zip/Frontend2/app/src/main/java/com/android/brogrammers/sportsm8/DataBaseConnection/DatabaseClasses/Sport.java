package com.android.brogrammers.sportsm8.DataBaseConnection.DatabaseClasses;

import java.io.Serializable;

/**
 * Created by Korbi on 21.06.2017.
 */

public class Sport implements Serializable {

    public int sportID,team,minPartySize,teamSize;
    public String sportname;
}
