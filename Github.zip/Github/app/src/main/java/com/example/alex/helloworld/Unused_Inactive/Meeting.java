package com.example.alex.helloworld.Unused_Inactive;

/**
 * Created by Korbi on 14.11.2016.
 */

public class Meeting {
    public String email;
    public String friend;
    public String confirmed,startTime,MeetingID,endTime;

}
