package com.example.alex.helloworld.Unused_Inactive;

/**
 * Created by Korbi on 02.11.2016.
 */

public class SportAttributes {
    String name;
    Integer draw;
    int ID;
    int team;
    Boolean funGame;
    Boolean ligaGame;
    Boolean training;
    Boolean nochEinButton;
}
